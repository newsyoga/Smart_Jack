#define WIFI_SSID "HOMEWIFI"
#define WIFI_PASSWD "862150909018"
#define MQTT_SERVER "54.66.215.200"
#define MQTT_USER "testdevice"
#define MQTT_PASSWD "arduino123"
#define MQTT_TOPIC "/8d746c7c-7e73-e88a-cbb8-6057a0f137a6/#"

